# Trae 提示词 — AcademicFlow 10 次速通搭大框架

> **Trae 直接从 GitHub 读取本文件及所有配套文档**，Rosa 不复制粘贴任何 md 内容。
> **本文件 URL**：`https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/TRAE_PROMPT.md`
> **配套文档**（必读）：
> - 主文档：`https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/TECH_SPEC_FOR_TRAE.md`
> - v0.2.5 原文归档：`https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/TECH_SPEC.md`
> - 项目记忆：`https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/PROJECT_HISTORY_FOR_TRAE.md`
>
> **Rosa 的操作**：在 Trae 对话框里输入"请先读这个文件再开工：https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/TRAE_PROMPT.md"，剩下 Trae 自己去拉。**不要复制任何 md 内容**。

Trae 仔细读完整个 prompt + 上述 3 份配套文档再开工。

---

## 你的任务

你是 Trae IDE AI，帮我（Rosa）从零搭建一个学术工作流 Web 应用 **AcademicFlow**。10 次速通把大框架搭完。

## 文档读取（必读，先读再开工）

> 下面 3 份文档**全部从 GitHub raw URL 拉取**，Rosa 不复制粘贴任何 md 内容。

1. **主文档**（自包含实施指南）：
   `https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/TECH_SPEC_FOR_TRAE.md`

2. **辅助文档**（v0.2.5 原文归档）：
   `https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/TECH_SPEC.md`

3. **项目记忆**（**必读** — 项目背景、踩过的坑、当前状态，避免你从零摸索）：
   `https://raw.githubusercontent.com/Nikki-SU/AcademicFlow/main/PROJECT_HISTORY_FOR_TRAE.md`

读完主文档后，**按 §13.3 必读章节清单顺序**通读，§0-§11 是产品/架构，§12 是引用与编译流程细节，§13 是给你的施工指南。
**第 3 份（项目记忆）尤其要看 §5.1「8MB PDF 上传失败 — 根因不在 worker 端」和 §6「项目硬约束」**。

## 仓库

- **Owner / Repo**：`Nikki-SU/AcademicFlow`
- **Branch**：`main`
- **当前部署**：GitHub Pages 静态 SPA（Vite + React + TypeScript）
- **首次初始化**：BYO 架构，使用者自带 GitHub PAT + 私库

## 目标

**10 次速通搭大框架**。每"次"= 1 轮你的输出。"速通"= 不纠结细节，按施工顺序每步拿到可跑通的最小可用版本。

**每步 1 次速通的标准**：

- 该步关键检查点（§13.2）跑通
- 给出看板（见下）
- 给出下一步计划

## 看板要求（每次输出必带）

每次你输出时，按以下格式给我看板：

```
## 📊 进度看板

**当前步**：步 N / 10 — [步名]
**完成项**：
- [x] 检查点 1
- [x] 检查点 2

**未完成项**：
- [ ] 检查点 3（原因：xxx）

**下一步计划**：进入步 N+1 — [下一步名]，重点做 xxx

**整体进度**：■■■■■■■□□□ 70%（7/10）
```

**看板原则**：

- 简洁，不超过 20 行
- 用 checkbox 格式（[x] / [ ]）让我能直接 copy 走
- 整体进度条用 ■ 和 □ 表示
- 不要列代码细节，只列检查点

## 打断控制（重点）

**不要中途频繁问我问题**。能默认的就默认，能推断的就推断。模糊的地方**用最合理的默认值 + 在代码注释里标 `// TODO: confirm with Rosa`**，不要打断我。

**已闭环问题不要再问**（v0.2.5 §9 决策记录已明确）：

- ❌ 不要问"用 SQLite 还是 md+csv"→ 已定 md+csv（§8.2）
- ❌ 不要问"AI 失败怎么兜底"→ 已定明示"AI 不可用"（§8.2）
- ❌ 不要问"关键词硬编码还是可配"→ 已定用户可配（§8.2）
- ❌ 不要问"参考文献追踪用哪个源"→ 已定多源（§8.2）
- ❌ 不要问"是否用 Vditor"→ 已定 Vditor ^3.10.4（§8.1）
- ❌ 不要问"是否用 Tauri"→ 已定 GitHub Pages 静态 SPA（§8.2）
- ❌ 不要问"是否引入 SQLite/Express 等后端"→ 已定 BYO 纯前端 + 浏览器 WASM（§8.2）
- ❌ 不要问"AI 用一个引擎还是两个"→ 已定 AI-1 + AI-2 双引擎（§6）
- ❌ 不要问"编译产物是 PDF 还是 Word"→ 已定两个都给（§5.8 + §12.4）
- ❌ 不要问"字段命名风格"→ 已定 snake_case + 后缀表义（§13.5）

**什么时候可以打断我**：

- 真的卡住，没法继续
- 涉及 v0.2.5 没明确的关键决策（极少见）
- 涉及不可逆操作（删文件、推 GitHub、装全局依赖等）

**打断时一次性问完所有问题**，不要问完一个等我回答再问下一个。

## 一次问好（步 1 开始时）

**v0.2.5 已经定的不要问**。具体：

- ❌ AI 选型 → **§6.4 已定**（使用者在 `settings/global.md` 自填 AI-1/AI-2 服务商与模型；推荐不同家，异构降共谋）
- ❌ GitHub 认证 flow / Token 存储 → **§1.12.1 / §1.12.2 已定**（Device Flow + Fine-grained PAT 双路径平权；IndexedDB 明文 + CSP/SRI/依赖锁死）
- ❌ 私库不存在时怎么处理 → **§7 / §7.1.1 已定**（自动创建 + 最小 API 序列）
- ❌ 仓库策略 → 默认在 `Nikki-SU/AcademicFlow` 现有仓库上继续（保留所有现有文件）
- ❌ 包管理器 / Tailwind 版本 / 路由库 / Tectonic 位置 / CSL 来源 / 字段命名 / 项目结构 → Trae 看 `package.json` / `tailwind.config.js` / §13.5 / §13.6 自己定

在步 1 开始时，**只问以下 1 个问题**：

1. **学习模块（Cat 借鉴）UI 风格**（§5.6 + §13.1 步 7）：
   - 暗色主题 / 亮色主题 / 跟随系统？
   - 是否需要夜间模式手动切换？

**这 1 个问题问完，我回答后开工步 1。**

### Trae 可以自己决定（不要问我）

- **仓库策略**：默认在 `Nikki-SU/AcademicFlow` 现有仓库上继续，保留所有现有文件
- **AI 选型**：使用者在 `settings/global.md` 自填（§6.4）；Trae 不用预设默认值，让 UI 提示用户填
- **认证 flow / Token 存储**：按 §1.12.1 / §1.12.2 实现
- **私库创建**：按 §7 / §7.1.1 实现
- **包管理器**：看 `package-lock.json` 决定 pnpm/npm/yarn
- **Tailwind 版本**：看 `tailwind.config.js` 决定 v3/v4
- **路由库**：看 `package.json` 决定 react-router v6/v7
- **8MB PDF 上传策略**：先按 8MB 实现（v0.2.5 §1.2 / §5 已定），后续再优化
- **Tectonic WASM 部署位置**：默认 `public/tectonic/`
- **CSL 模板来源**：默认 `citation-js` 内置（更简单）
- **字段命名规范**：§13.5 已定（snake_case + 后缀表义）
- **项目结构**：§13.6 已定

## 10 步施工顺序（§13.1）

| 步 | 主题 | 关键检查点 |
|---|---|---|
| 1 | 项目骨架 + 首启初始化 | `npm run dev` 看到 BYO 初始化提示 |
| 2 | Vditor 编辑器 | 7 块类型 + 图片 base64 + 1.5s 防抖 |
| 3 | 引用语法层 | DOI/DOI 链接双输入兼容 |
| 4 | 投稿编译（LaTeX） | 引擎链降级 + `\cite{}` 映射 |
| 5 | 投稿编译（Word） | Pandoc WASM 化 |
| 6 | AI 双引擎 | AI-1 → AI-2 校验通过 |
| 7 | 学习模块 | 3 tab + 6 题型 + SM-2 |
| 8 | 关键词追踪 | 4 源并行 |
| 9 | 数据存储 + 字段命名 | md+csv + 字段统一 |
| 10 | 集成测试 + UI 打磨 | 8MB PDF 上传 + 编译产物 |

每步详细说明看 `TECH_SPEC_FOR_TRAE.md` §13.1-13.2。

## 实施原则

1. **每步先跑通再优化**：不要在第 1 步就纠结 UI 像素，先能跑
2. **代码注释标 TODO**：模糊决策标 `// TODO: confirm with Rosa: xxx`，我会在下次 review 时统一处理
3. **每步完成后跑 §13.2 检查点**：不要跳检查点
4. **遵循 §1 全局硬约束**：违反任何一条 = 重做
5. **遵循 §8 借鉴清单**：§8.1 继承的要用，§8.2 切断的不要用
6. **遵循 §9 决策记录**：已闭环的不要重提
7. **遵循 §12 引用细节**：DOI/DOI 链接双输入 + LaTeX `\cite{}` 映射 + 排序
8. **遵循 §13.5 字段命名规范**：snake_case + 后缀表义
9. **遵循 §13.6 项目结构**：不要乱建目录
10. **每步末报告**：
    - 本步新增/修改文件清单
    - 本步关键检查点结果
    - 遇到的问题 + 你的决策
    - 下一步计划

## 异常处理

- **遇到 v0.2.5 没明确的决策** → 选最合理默认 + 标 TODO + 继续推进，**不要打断我**
- **遇到技术错误** → 自己 debug 跑通，**不要打断我**
- **遇到 v0.2.5 §1 硬约束冲突** → 停下来，在 TODO 里标 `// BLOCKED: violates §1.X`，等步末报告时统一说
- **遇到 v0.2.5 §9 决策记录已闭环但你想改** → 标 `// CONFLICT: §9.X says X, but I want Y, reason: Z`，步末报告时统一说

## 开工

读完 `TECH_SPEC_FOR_TRAE.md` 后，先问完 1 个一次问好的问题（学习模块 UI 风格），再开始步 1。

**不要省略一次问好的步骤**。我要的是稳，不是快。

---

*本提示词是 Rosa 给你（Trae）的完整指令。版本：v1.3*
*配套文档：*
- `TECH_SPEC_FOR_TRAE.md`（**必读**，产品架构 + 实现细节）
- `TECH_SPEC.md`（v0.2.5 原文归档，可选参考）
- `PROJECT_HISTORY_FOR_TRAE.md`（**必读**，项目记忆 + 踩过的坑 + 当前状态）

*全部走 GitHub raw URL 拉取，Rosa 不复制粘贴任何 md。*

*版本说明：*
- v1.1 把"一次问好"从 8 个问题砍到 4 个
- v1.2 把"一次问好"从 4 个问题砍到 1 个（只留学习模块 UI 风格）。v0.2.5 §6.4 / §1.12.1 / §1.12.2 / §7 / §7.1.1 已经定的事项（AI 选型 / 认证 flow / Token 存储 / 私库创建）一律默认掉
- v1.3 文件头改为"Trae 从 GitHub URL 读取"（不再让 Rosa 复制粘贴任何 md），因为 Trae 不能接收直粘 md
